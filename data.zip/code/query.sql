SELECT accommodation_id, locality_id AS destination_id
FROM accommodation
WHERE date = {date}
